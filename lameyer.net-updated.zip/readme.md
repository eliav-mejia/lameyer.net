LaMeyer.net
/* Sitio Web */

Static site on GitHub Pages (custom domain `lameyer.net`, proxied by Cloudflare).
No build step: pages use Tailwind, React and Babel from CDNs.

## Folder structure

```
lameyer.net/
├── CNAME                         custom domain for GitHub Pages
├── readme.md                     this file
├── index.html                    home page (/)
│
├── css/
│   └── site.css                  shared styles: circuit background, glass, animations
│
├── js/
│   ├── layout.jsx                shared by EVERY page: header, footer, contact form,
│   │                             PageHero, RegisterCTA, tech stack, renderPage()
│   └── blog.jsx                  blog only: BLOG_POSTS list, dashboard, article template
│
├── pages/                        one folder per section, served at /pages/<name>/
│   ├── development/index.html    /pages/development/  (contact form -> Google Sheets)
│   ├── components/index.html     /pages/components/
│   ├── community/index.html      /pages/community/
│   └── stack/index.html          /pages/stack/
│
└── blog/
    ├── index.html                /blog/  filter dashboard
    └── <Entry_Name>/index.html   /blog/<Entry_Name>/  one folder per entry
        ├── Edge_Layer_(DDoS_&_DNS)/
        ├── WAF_&_Bot_Layer_(Layer_7)/
        ├── API_Endpoint_Protection/
        ├── Rate_Limiting/
        └── Cloudflare_Tunnel/
```

## What each page loads

| Page                   | css/site.css | js/layout.jsx | js/blog.jsx | GSAP |
|------------------------|:------------:|:-------------:|:-----------:|:----:|
| `index.html`           | ✓            | ✓             |             | ✓    |
| `pages/development/`   | ✓            | ✓             |             | ✓    |
| `pages/components/`    | ✓            | ✓             |             |      |
| `pages/community/`     | ✓            | ✓             |             |      |
| `pages/stack/`         | ✓            | ✓             |             |      |
| `blog/`                | ✓            | ✓             | ✓           |      |
| `blog/<Entry>/`        | ✓            | ✓             | ✓           |      |

Order matters: `js/layout.jsx` always loads first, then `js/blog.jsx` (blog pages only),
then the page's own inline script, which ends with `renderPage(MyPage)`.

## Common edits

- **Header links**: `NAV_LINKS` in `js/layout.jsx` (updates every page).
- **Contact form fields / Google Apps Script URL**: `ContactForm` and `FORM_ENDPOINT` in `js/layout.jsx`.
  Field names (`NOMBRE`, `ORGANIZACIÓN`, `TELÉFONO`, `EMAIL`, `TECNOLOGÍA`) must match the Google Sheet columns.
- **Email address**: `CONTACT_EMAIL` in `js/layout.jsx`.
- **Tech stack**: `TECH_STACK` in `js/layout.jsx` (home page and `/pages/stack/`).

## Add a page

1. Copy `pages/stack/` to `pages/<new-name>/` and edit its `index.html`.
2. Add `{ href: '/pages/<new-name>/', label: '...' }` to `NAV_LINKS` in `js/layout.jsx`.

## Add a blog entry

1. Copy an entry folder, e.g. `blog/Rate_Limiting/` to `blog/My_New_Entry/`.
2. In its `index.html` change `CONTROLS`, `Content` and the path in `renderPost('/blog/My_New_Entry/', ...)`.
3. Add an object with the same `path` to `BLOG_POSTS` in `js/blog.jsx`.
4. Optional: add it to `BLOG_HIGHLIGHTS` in `index.html` to show it on the home page.

Always link with a trailing slash (`/pages/stack/`, `/blog/My_New_Entry/`).
